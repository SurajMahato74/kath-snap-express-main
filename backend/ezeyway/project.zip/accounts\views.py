from django.shortcuts import render
from django.http import JsonResponse

def login_view(request):
    return JsonResponse({'message': 'Login view'})

def register_view(request):
    return JsonResponse({'message': 'Register view'})
