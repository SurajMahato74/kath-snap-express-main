import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY
SECRET_KEY = 'django-insecure-g)8be^pfjk9cd+h!u)9$8(emxu7jj03mn$q7@7=^0t=(t=w81&'
DEBUG = True  # Set to False in production
ALLOWED_HOSTS = ['127.0.0.1', 'localhost', 'ezeyway.com', 'www.ezeyway.com']  # Replace with your domain/subdomain

# Installed apps
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'accounts',
]

# Middleware
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'ezeyway.urls'

# Database (MySQL)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'ezeyway',       # MySQL database name
        'USER': 'root',       # MySQL username
        'PASSWORD': 'root',   # MySQL password
        'HOST': 'localhost',          # Usually localhost in cPanel
        'PORT': '3306',               # Default MySQL port
    }
}

WSGI_APPLICATION = 'ezeyway.wsgi.application'

# Static files (CSS, JS)
STATIC_URL = '/assets/'
STATICFILES_DIRS = [
    BASE_DIR / "dist" / "assets",
]
STATIC_ROOT = BASE_DIR / "staticfiles"

# Media files (React build)
MEDIA_URL = '/'
MEDIA_ROOT = BASE_DIR / "dist"

# Templates (React index.html)
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / "dist"],  # React index.html
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
